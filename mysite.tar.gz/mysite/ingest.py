import sys
import requests
import django
django.setup()

from djangodb.models import TVSeries
from djangodb.models import Season
from djangodb.models import Episode

from environs import Env

env = Env()
env.read_env()


class Config(object):
    omdb_api_url = env.str('OMDB_API_URL', 'https://www.omdbapi.com/')
    omdb_api_key = env.str('OMDB_API_KEY', '560c1bb6')
    omdb_verify_ssl = env.bool('OMDB_VERIFY_SSL', True)


def fetch_tv_series(config: Config, series: str):
    series_filter = "?t=" + series + "&" + "apikey="
    url = config.omdb_api_url + series_filter + config.omdb_api_key
    headers = {'Content-Type': "application/json", 'cache-control': "no-cache"}
    response = requests.get(url=url, headers=headers, verify=config.omdb_verify_ssl)
    response_dict = response.json()
    total_season = response_dict['totalSeasons']
    return total_season 

def fetch_season(config: Config, title: str, season: int):
    series_filter = "?t=" + title + "&" + "Season=" + str(season) + "&" + "apikey="
    url = config.omdb_api_url + series_filter + config.omdb_api_key
    headers = {'Content-Type': "application/json", 'cache-control': "no-cache"}
    response = requests.get(url=url, headers=headers, verify=config.omdb_verify_ssl)
    response_dict = response.json()
    episodes = response_dict['Episodes']
    return episodes

def fetch_episode(config: Config, imdb_id: str):
    episode_filter = "?i=" + imdb_id + "&" + "apikey="
    url = config.omdb_api_url + episode_filter + config.omdb_api_key
    headers = {'Content-Type': "application/json", 'cache-control': "no-cache"}
    response = requests.get(url=url, headers=headers, verify=config.omdb_verify_ssl)
    episode = response.json()
    return episode
  

def ingestion(): 
    if (sys.version_info < (3, 0)):
        print("This tool needs python3!'")
        sys.exit(1)

    config = Config()

    title = "Game of Thrones"
    total_season = fetch_tv_series(config, title)
    tvseries_tuple = TVSeries.objects.get_or_create(title=title, total_season=total_season)
    tvseries = tvseries_tuple[0]

    for season_number in range(1, int(total_season) + 1):
        season_tuple = Season.objects.get_or_create(tvseries=tvseries, season_number=str(season_number))
        season = season_tuple[0]
        episodes = fetch_season(config, title, season_number)

        for episode in episodes:
            imdb_id = episode['imdbID']
            episode_details = fetch_episode(config, imdb_id)
            print("Fetched season " + str(season_number) + " episode " + str(episode_details['Episode']))
            Episode.objects.get_or_create(season=season, title=episode_details['Title'], plot=episode_details['Plot'], genre=episode_details['Genre'], imdb_rating=episode_details['imdbRating'], episode_number = int(episode_details['Episode']), season_number = int(episode_details['Season']), language = episode_details['Language'], imdb_id=episode_details['imdbID'])
  
            


if __name__ == "__main__":
    ingestion()

