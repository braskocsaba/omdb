from django.conf.urls import url
from django.urls import path, include
from .views import (
    EpisodeListApiView,
    EpisodeDetailApiView
)

urlpatterns = [
    path('api', EpisodeListApiView.as_view()),
    path('api/<str:imdb_id>/', EpisodeDetailApiView.as_view()),
]
