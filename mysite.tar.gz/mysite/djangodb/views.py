from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Episode
from .serializers import EpisodeSerializer

class EpisodeListApiView(APIView):

    #  List all
    def get(self, request, *args, **kwargs):
        '''
        List all the items episode 
        '''
        episodes = Episode.objects.all() 
        serializer = EpisodeSerializer(episodes, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

class EpisodeDetailApiView(APIView):

    def get_object(self, imdb_id):
        try:
            return Episode.objects.get(imdb_id=imdb_id)
        except Episode.DoesNotExist:
            return None

    def get(self, request, imdb_id, *args, **kwargs):
        '''
        Retrieves the Episode with given imdb_id
        '''
        episode_instance = self.get_object(imdb_id)
        if not episode_instance:
            return Response(
                {"res": "Object with imdb_id does not exists"},
                status=status.HTTP_400_BAD_REQUEST
            )

        serializer = EpisodeSerializer(episode_instance)
        return Response(serializer.data, status=status.HTTP_200_OK)
