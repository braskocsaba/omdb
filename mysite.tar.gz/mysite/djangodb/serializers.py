from rest_framework import serializers
from .models import Episode, Season, TVSeries
class EpisodeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Episode
        fields = ["title", "plot", "genre", "episode_number", "season_number", "imdb_rating", "language", "imdb_id" ]
