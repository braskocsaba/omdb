from django.db import models

class TVSeries(models.Model):
    title = models.CharField(max_length=200, primary_key=True)
    total_season = models.PositiveSmallIntegerField(null=True)


class Season(models.Model):
    tvseries = models.ForeignKey('TVSeries', on_delete=models.CASCADE, null=True)
    season_number  = models.CharField(max_length=200)


class Episode(models.Model):
    season = models.ForeignKey('Season', on_delete=models.CASCADE, blank=False, null=False, )
    title = models.CharField(max_length=200, primary_key=True)
    plot = models.CharField(max_length=2000)
    genre = models.CharField(max_length=200)
    imdb_rating = models.CharField(max_length=5)
    season_number = models.PositiveSmallIntegerField(null=True)
    episode_number = models.PositiveSmallIntegerField(null=True)
    language = models.CharField(max_length=50)
    imdb_id = models.CharField(max_length=15, null=True)

